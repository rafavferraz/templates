#include <iostream>



inline void printFunction() {

  std::cout << "hello from test function." << std::endl;

}